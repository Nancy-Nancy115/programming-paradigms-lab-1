﻿let applyExponent exponent value =                              //1. partial Application
    value ** float exponent

let square = applyExponent 2
let cube = applyExponent 3

let squareResults = [square 2.0; square 3.0; square 4.0] 
let cubeResults = [cube 2.0; cube 3.0; cube 4.0]         

printfn "Square results: %A" squareResults
printfn "Cube results: %A" cubeResults








let rec productTailRecursive list accumulator =                   //2. Tail Recursion 1
    match list with
    | [] -> accumulator
    | x :: xs -> productTailRecursive xs (accumulator * x)

let product = productTailRecursive [1; 2; 3; 4] 1
printfn "Product of list elements: %d" product








let rec productOddNumbers n accumulator =                        //3. Tail Recursion 2
    if n < 1 then accumulator
    else productOddNumbers (n - 2) (accumulator * n)

let oddProduct = productOddNumbers 11 1
printfn "Product of odd numbers: %d" oddProduct

  




                             //4. Using Map Function with a Collection:

let nameList: string list = ["Nancy"; "Roban "; "Mandeep"; "Swati"]

let trimmedNames = List.map (fun (name: string) -> name.Trim()) nameList

printfn "Trimmed Names: %A" trimmedNames










                        //5. Using Filter and Reduce with a Collection

let sequence = [1..700]                                   
let filtered = List.filter (fun x -> x % 7 = 0 && x % 5 = 0) sequence
let sum = List.reduce (+) filtered

printfn "Sum of multiples of 7 and 5: %d" sum








                         //6. Using Filter and Reduce with Collection of Strings

let names: string list = ["Nancy"; "Roban"; "Garima"; "Isha"; ""; "Divya"; "Moni"]

let filteredNames = List.filter (fun (name: string) -> name.ToLower().Contains("i")) names

let concatenatedNames = List.reduce (+) filteredNames

printfn "Concatenated Names: %s" concatenatedNames
  